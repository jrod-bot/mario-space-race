import { useEffect, useRef } from "react";

/* ─────────────────────────── data ─────────────────────────── */

const NAV_LINKS = [
  { href: "#overview",     label: "Overview" },
  { href: "#timeline",     label: "Timeline" },
  { href: "#tensions",     label: "Tensions" },
  { href: "#impact",       label: "Impact" },
  { href: "#significance", label: "Significance" },
  { href: "#concepts",     label: "Concepts" },
  { href: "#images",       label: "Images" },
];

const TIMELINE_EVENTS = [
  {
    year: "1957",
    emoji: "🛰️",
    title: "Sputnik Launched",
    detail: "The Soviet Union launches Sputnik 1 — the first artificial satellite to orbit Earth, shocking the West.",
    side: "left" as const,
    color: "#e84040",
  },
  {
    year: "1958",
    emoji: "🚀",
    title: "NASA Founded",
    detail: "The United States creates NASA in direct response to Sputnik, ramping up America's space program.",
    side: "right" as const,
    color: "#f59e0b",
  },
  {
    year: "1961",
    emoji: "👨‍🚀",
    title: "Yuri Gagarin in Space",
    detail: "Soviet cosmonaut Yuri Gagarin becomes the first human in space, completing one orbit of Earth.",
    side: "left" as const,
    color: "#e84040",
  },
  {
    year: "1963",
    emoji: "👩‍🚀",
    title: "First Woman in Space",
    detail: "Soviet cosmonaut Valentina Tereshkova becomes the first woman to travel to space.",
    side: "right" as const,
    color: "#f59e0b",
  },
  {
    year: "1969",
    emoji: "🌕",
    title: "Moon Landing",
    detail: 'Apollo 11 lands on the Moon. Neil Armstrong declares: "That\'s one small step for man, one giant leap for mankind."',
    side: "left" as const,
    color: "#3b82f6",
  },
];

const CONCEPTS = [
  { term: "Containment",   icon: "🛡️", def: "U.S. policy to stop the spread of communism globally." },
  { term: "Expansionism",  icon: "🗺️", def: "Soviet drive to extend influence and power beyond its borders." },
  { term: "Brinkmanship",  icon: "⚖️", def: "Pushing a dangerous situation to the edge to force a favourable outcome." },
  { term: "Deterrence",    icon: "☢️", def: "Preventing aggression through the threat of severe retaliation." },
  { term: "Alignment",     icon: "🤝", def: "Nations choosing sides — NATO (West) or Warsaw Pact (East)." },
];

const STARS = Array.from({ length: 60 }, (_, i) => ({
  id: i,
  top: `${Math.random() * 100}%`,
  left: `${Math.random() * 100}%`,
  dur: `${1.5 + Math.random() * 2.5}s`,
  size: Math.random() > 0.85 ? 4 : 2,
}));

const COINS = [
  { left: "12%",  dur: "5s",  delay: "0s"   },
  { left: "35%",  dur: "7s",  delay: "2.2s" },
  { left: "58%",  dur: "6s",  delay: "1.1s" },
  { left: "78%",  dur: "8s",  delay: "3.5s" },
  { left: "90%",  dur: "5.5s",delay: "0.8s" },
];

/* ─────────────────────────── helpers ─────────────────────────── */

function scrollTo(id: string, e: React.MouseEvent) {
  e.preventDefault();
  document.querySelector(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

/* ─────────────────────────── component ─────────────────────────── */

const Index = () => {
  const headerRef = useRef<HTMLDivElement>(null);

  // parallax-lite: header text moves slightly on scroll
  useEffect(() => {
    const onScroll = () => {
      if (headerRef.current) {
        headerRef.current.style.transform = `translateY(${window.scrollY * 0.25}px)`;
        headerRef.current.style.opacity = `${1 - window.scrollY / 320}`;
      }
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="mario-page">

      {/* ── Stars ── */}
      {STARS.map(s => (
        <span
          key={s.id}
          className="star"
          style={{
            top: s.top,
            left: s.left,
            ["--dur" as string]: s.dur,
            width: s.size,
            height: s.size,
          }}
        />
      ))}

      {/* ── Coins ── */}
      {COINS.map((c, i) => (
        <span
          key={i}
          className="coin"
          style={{
            left: c.left,
            ["--coin-dur" as string]: c.dur,
            ["--coin-delay" as string]: c.delay,
          }}
        >
          🪙
        </span>
      ))}

      {/* ── Jumping Mario ── */}
      <span className="mario-sprite">🍄</span>

      {/* ══ HEADER ══════════════════════════════════════════════ */}
      <header className="relative z-10 bg-red-600 text-yellow-300 text-center py-8 px-6 shadow-2xl border-b-4 border-yellow-400">
        <div ref={headerRef}>
          <p className="text-sm font-bold tracking-widest uppercase text-yellow-200 mb-1">Cold War History</p>
          <h1 className="text-4xl md:text-5xl font-extrabold drop-shadow-lg leading-tight">
            🍄 Super Mario Space Race 🚀
          </h1>
          <p className="mt-2 text-yellow-200 text-base font-medium">
            Power-Up your knowledge of the Cold War's greatest rivalry
          </p>
        </div>
      </header>

      {/* ══ NAV ═════════════════════════════════════════════════ */}
      <nav className="mario-nav sticky top-0 z-20 bg-amber-900/90 backdrop-blur border-b-2 border-amber-700 px-4 py-2 flex flex-wrap items-center justify-center gap-1">
        {NAV_LINKS.map(l => (
          <a
            key={l.href}
            href={l.href}
            onClick={e => scrollTo(l.href, e)}
            className="px-3 py-1.5 text-sm font-bold text-white"
          >
            {l.label}
          </a>
        ))}
      </nav>

      {/* ══ CONTENT ═════════════════════════════════════════════ */}
      <main className="relative z-10 max-w-4xl mx-auto px-4 py-10 space-y-10">

        {/* Overview */}
        <section id="overview" className="mario-card p-6 md:p-8">
          <h2 className="text-2xl font-extrabold text-red-600 mb-3">🚀 What Happened?</h2>
          <p className="text-gray-700 leading-relaxed mb-4">
            The Space Race was a Cold War competition between the United States and the Soviet Union.
            It began in 1957 with Sputnik and culminated with the U.S. Moon landing in 1969.
          </p>
          <div className="grid sm:grid-cols-3 gap-3">
            {[
              { year: "1957", label: "Sputnik launched", emoji: "🛰️" },
              { year: "1961", label: "Yuri Gagarin in space", emoji: "👨‍🚀" },
              { year: "1969", label: "Moon landing", emoji: "🌕" },
            ].map(e => (
              <div key={e.year} className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
                <div className="text-3xl mb-1">{e.emoji}</div>
                <div className="text-2xl font-extrabold text-blue-700">{e.year}</div>
                <div className="text-sm text-gray-600 mt-1">{e.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Timeline */}
        <section id="timeline" className="mario-card p-6 md:p-8">
          <h2 className="text-2xl font-extrabold text-red-600 mb-6">📅 Timeline of Events</h2>

          <div className="relative">
            {/* central line */}
            <div className="timeline-line hidden md:block" />

            <div className="space-y-8">
              {TIMELINE_EVENTS.map((ev, i) => (
                <div
                  key={ev.year}
                  className={`flex items-start gap-4 md:gap-0 ${
                    ev.side === "right" ? "md:flex-row-reverse" : "md:flex-row"
                  }`}
                >
                  {/* card */}
                  <div className={`md:w-[46%] ${ev.side === "right" ? "md:text-right md:pl-6" : "md:pr-6"}`}>
                    <div
                      className="rounded-xl p-4 border-l-4 md:border-l-0 shadow-sm"
                      style={{
                        background: `${ev.color}12`,
                        borderColor: ev.color,
                        borderLeftColor: ev.color,
                        ...(ev.side === "right"
                          ? { borderRight: `4px solid ${ev.color}`, borderLeft: "none" }
                          : { borderLeft: `4px solid ${ev.color}` }),
                      }}
                    >
                      <div className="flex items-center gap-2 mb-1" style={{ justifyContent: ev.side === "right" ? "flex-end" : "flex-start" }}>
                        <span className="text-xl">{ev.emoji}</span>
                        <span className="text-xs font-bold px-2 py-0.5 rounded-full text-white" style={{ background: ev.color }}>
                          {ev.year}
                        </span>
                      </div>
                      <h3 className="font-extrabold text-gray-800 text-base">{ev.title}</h3>
                      <p className="text-sm text-gray-600 mt-1 leading-relaxed">{ev.detail}</p>
                    </div>
                  </div>

                  {/* centre dot */}
                  <div className="hidden md:flex w-[8%] justify-center pt-3 flex-shrink-0">
                    <div
                      className="w-5 h-5 rounded-full border-4 border-white shadow-md z-10 flex-shrink-0"
                      style={{ background: ev.color }}
                    />
                  </div>

                  {/* spacer */}
                  <div className="hidden md:block md:w-[46%]" />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Tensions */}
        <section id="tensions" className="mario-card p-6 md:p-8">
          <h2 className="text-2xl font-extrabold text-red-600 mb-3">🔥 Tensions</h2>
          <p className="text-gray-700 leading-relaxed">
            The Space Race intensified Cold War tensions by creating a sense of technological competition and mutual fear.
            Each achievement by one side was seen as a military and ideological threat by the other — rockets that launch
            satellites could just as easily deliver nuclear warheads.
          </p>
        </section>

        {/* Impact */}
        <section id="impact" className="mario-card p-6 md:p-8">
          <h2 className="text-2xl font-extrabold text-red-600 mb-4">🌎 Impact</h2>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">🇺🇸</span>
                <span className="font-extrabold text-blue-800">USA</span>
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">
                Advanced technology and national pride peaked with the Moon landing. NASA breakthroughs influenced
                computing, medicine, and materials science for decades.
              </p>
            </div>
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">🇷🇺</span>
                <span className="font-extrabold text-red-800">USSR</span>
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">
                Early success with Sputnik and Gagarin established Soviet prestige. However, the Soviet program
                fell behind after 1966 and never achieved a crewed Moon mission.
              </p>
            </div>
          </div>
        </section>

        {/* Significance */}
        <section id="significance" className="mario-card p-6 md:p-8">
          <h2 className="text-2xl font-extrabold text-red-600 mb-3">⭐ Significance</h2>
          <p className="text-gray-700 leading-relaxed">
            The Space Race produced major scientific advancements and became the defining symbol of Cold War rivalry.
            It proved that ideology could drive nations to achieve the seemingly impossible — and it gave the world
            GPS, satellite TV, and the internet's early foundations.
          </p>
        </section>

        {/* Concepts */}
        <section id="concepts" className="mario-card p-6 md:p-8">
          <h2 className="text-2xl font-extrabold text-red-600 mb-4">🎯 Key Concepts</h2>
          <div className="space-y-3">
            {CONCEPTS.map(c => (
              <div key={c.term} className="flex items-start gap-3 bg-gray-50 border border-gray-200 rounded-xl p-4">
                <span className="text-2xl flex-shrink-0">{c.icon}</span>
                <div>
                  <span className="font-extrabold text-gray-800">{c.term}</span>
                  <p className="text-sm text-gray-600 mt-0.5">{c.def}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Images */}
        <section id="images" className="mario-card p-6 md:p-8">
          <h2 className="text-2xl font-extrabold text-red-600 mb-4">🖼️ Images</h2>
          <div className="grid sm:grid-cols-2 gap-6">
            <figure className="text-center">
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/b/be/Sputnik_asm.jpg"
                alt="Sputnik satellite"
                className="w-full rounded-xl shadow-md border border-gray-200 object-cover aspect-[4/3]"
              />
              <figcaption className="mt-2 text-sm text-gray-600 font-medium">
                🛰️ Sputnik 1 — first satellite ever to orbit Earth (1957)
              </figcaption>
            </figure>
            <figure className="text-center">
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/a/a1/Aldrin_Apollo_11.jpg"
                alt="Buzz Aldrin on the Moon, Apollo 11"
                className="w-full rounded-xl shadow-md border border-gray-200 object-cover aspect-[4/3]"
              />
              <figcaption className="mt-2 text-sm text-gray-600 font-medium">
                🌕 Apollo 11 Moon Landing — U.S. victory (1969)
              </figcaption>
            </figure>
          </div>
        </section>

      </main>

      {/* ══ FOOTER ══════════════════════════════════════════════ */}
      <footer className="relative z-10 bg-red-600 text-yellow-200 text-center py-5 px-4 mt-10 border-t-4 border-yellow-400">
        <p className="font-bold text-lg">🍄 Mario + History = Power-Up Learning ⭐</p>
        <p className="text-xs text-yellow-300 mt-1 opacity-75">Student presentation · Cold War unit</p>
      </footer>

    </div>
  );
};

export default Index;
